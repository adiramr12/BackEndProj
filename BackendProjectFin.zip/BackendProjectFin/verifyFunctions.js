const MongoClient  = require('mongodb').MongoClient;
const dotenv = require('dotenv');
const mongoose = require('mongoose');
const User = require('./models/user');
dotenv.config();

async function verifyCategory(category) { // verify category is one of the allowed values
    const allowedCategories = ['breakfast', 'lunch', 'dinner', 'other'];
    if (!allowedCategories.includes(category.toLowerCase())) {
        console.log('Invalid category. Must be one of: breakfast, lunch, dinner, other');
        return false; // Need to be changed and not send back to the same page
    }
    return true;
}
async function verifyMonth(month) { //verify month is between 1 and 12
    if (month>12 || month<1) {
        console.log('Invalid month. Must be between 1 and 12');
        return false;
    }
    return true;
}
async function verifyDay(day) { //verify day is between 1 and 31
    if (day>31 || day<1) {
        console.log('Invalid day. Must be between 1 and 31');
        return false;
    }
    return true;
}
async function verifyUser(userID) { //verify user is a valid mongo ID
    try {
        // Check if the userID exists in the database
        console.log('Verifying user:', userID);
        const user = await User.findOne({ id: parseInt(userID) });
        console.log('User found:', user);
        // If user is null, it means userID does not exist in the database
        if (!user) {
            console.log('User not found');
            return false;
        }
        // If user is found, return true
        return true;
    } catch (error) {
        console.error('Error verifying user:', error);
        throw error; // Rethrow the error to be handled by the caller
    }
}
async function verifyAmount(amount) { // verify amount is a positive number
    if (amount < 0) {
    console.log('Invalid amount. Must be a positive number');
    return false;
    }
    return true;
}

module.exports = { verifyCategory, verifyMonth, verifyDay, verifyUser, verifyAmount };

