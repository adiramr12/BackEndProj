const mongoose = require('mongoose');

const Schema= mongoose.Schema;

const ItemSchema = new Schema({
    user_id: {type: Number},
    year: {type: Number},
    month: {type: Number},
    day: {type: Number},
    description: {type: String},
    category: {type: String},
    amount: {type: Number}
});

const Item = mongoose.model('calories', ItemSchema);

module.exports =  Item;