const mongoose = require('mongoose');

const Schema= mongoose.Schema;

const UserSchema = new Schema({
    user_id: {type: Number},
    first_name: {type: String},
    last_name: {type: String},
    birthday: {type: Date}
});

const User = mongoose.model('users', UserSchema);

module.exports = User;