
const errorHandler = (error, req, res, next) => {
    console.log(error.message);
    if (error.type === 'operational') {
        res.status(400).send(error.message);
    } else if (error.type === 'server') {
        res.status(500).send(error.message);
    } else {
       return next(error); // Pass to the next error handling middleware
    }
};
module.exports = errorHandler ;
