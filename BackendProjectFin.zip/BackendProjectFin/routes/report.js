const express = require('express');
const router = express.Router();
const Item = require('../models/item');
const verifyFunctions= require('../verifyFunctions');

// this get route is for the report testing purposes

router.get('/reportGet', function(req, res, next) {
    res.sendFile(__dirname + '/report.html');
});
/* GET home page. */
router.get('/', async (req, res,next) => {
    const { user_id, year, month } = req.query;

    const userid= parseInt(user_id);
    const yearid= parseInt(year);
    const monthid= parseInt(month);
    console.log(userid,yearid,monthid);
    try {

        // Verify user
        const userValid = await verifyFunctions.verifyUser(user_id);
        if (!userValid) {
            console.log('User not found');
            const error = new Error('User not found');
            error.type= 'operational';
            throw error;
        }

        // Fetch items matching the provided user_id, year, and month
        const items = await Item.find({ user_id: userid, year: yearid, month: monthid}).exec();
        console.log('Items found:', items);
        if (items.length === 0) {
            // Handle the case where no items were found
            console.log("No items found for the specified criteria.");
            const error = new Error('No items found for the specified criteria');
            error.type= 'operational';
            throw error;
            // You might want to return a specific response, throw an error, or handle it in another way
        }
        // Construct the JSON document
        const report = {
            breakfast: [],
            lunch: [],
            dinner: [],
            other: []
        };

        // Iterate through the fetched items and categorize them
        items.forEach(item => {
            switch (item.category) {
                case 'breakfast':
                    report.breakfast.push({
                        day: item.day,
                        description: item.description,
                        amount: item.amount
                    });
                    break;
                case 'lunch':
                    report.lunch.push({
                        day: item.day,
                        description: item.description,
                        amount: item.amount
                    });
                    break;
                case 'dinner':
                    report.dinner.push({
                        day: item.day,
                        description: item.description,
                        amount: item.amount
                    });
                    break;
                default:
                    report.other.push({
                        day: item.day,
                        description: item.description,
                        amount: item.amount
                    });
            }
        });

        // Send the constructed report as JSON response
        res.json(report);
    } catch (err) {
        // Handle errors
        next(err);
    }
});

module.exports = router;
