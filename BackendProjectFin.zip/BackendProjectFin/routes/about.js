const express = require('express');
const router = express.Router();

// Sample data for developers
const developers = [
    { id: 207685645, firstname: 'Adir', lastname: 'Amar', email: 'adiramr12@gmail.com' },
    { id: 315444596, firstname: 'Guy', lastname: 'Mizrahi', email: 'guy15.mizrahi@gmail.com' },
    // Add more developers as needed
];

// Endpoint to get developer information
router.get('/', (req, res) => {
    res.status(200).json(developers);
});

module.exports = router;
