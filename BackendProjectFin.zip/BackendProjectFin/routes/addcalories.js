const express = require('express');
const router = express.Router();
const Item = require('../models/item');
const verifyFunctions= require('../verifyFunctions');
/* GET home page. */


// this get route is for the addCalories testing purposes
router.get('/', function(req, res, next) {
    res.sendFile(__dirname + '/addCalories.html');
});

router.post('/', async (req, res, next) => {
    // Post is Asyncronous, so we need to use try/catch
    try {
        const { user_id, year, month, day, description, category, amount } = req.body;


        // Verify category
        const categoryValid = await verifyFunctions.verifyCategory(category);
        if (!categoryValid) {
            const error = new Error('Invalid category. Must be one of: breakfast, lunch, dinner, other');
            error.type= 'operational';
            throw error;
        }

        // Verify month
        const monthValid = await verifyFunctions.verifyMonth(month);
        if (!monthValid) {
            const error = new Error('Invalid month. Must be between 1 and 12');
            error.type= 'operational';
            throw error;
        }

        // Verify day
        const dayValid = await verifyFunctions.verifyDay(day);
        if (!dayValid) {
            const error = new Error('Invalid day. Must be between 1 and 31');
            error.type= 'operational';
            throw error;
        }

        // Verify user
        const userValid = await verifyFunctions.verifyUser(user_id);
        if (!userValid) {
            const error = new Error('User not found');
            error.type= 'operational';
            throw error;
        }

        // Verify amount
        const amountValid = await verifyFunctions.verifyAmount(amount);
        if (!amountValid) {
            const error = new Error('Invalid amount. Must be a positive number');
            error.type= 'operational';
            throw error;
        }

        // If all verifications pass, create the item
        return Item.create(req.body)
            .then((item) => {
                res.status(201).json(item);
                console.log("Item added successfully:", item);
            })
            .catch((err) => {
                res.status(500).json({ error: 'Internal Server Error' });
            });
    } catch (err) {
        next(err);
    }
});

module.exports = router;


